#valoarea 0 reprezinta alb
#valoarea 1 reprezinta negru
#valoare intre 0 si 1 reprezinta gri
#Digit recognizer
#cifre scrise de mana
#inputurile corespund cu pixeli


#Output o sa fie un vector cu 10 componente
# Numarul zero reprezentat in vector: [1,0,0,0,0,0,0,0,0,0]
# Numarul unu reprezentat in vector:  [0,1,0,0,0,0,0,0,0,0]
#…

import numpy as np
import matplotlib.pyplot as plt
import random
import gzip
import pickle
from p2 import NeuronalNetwork


with gzip.open('mnist.pkl.gz', 'rb') as fd:
    train_set, valid_set, test_set = pickle.load(fd, encoding='latin')

neural_network = NeuronalNetwork()
neural_network.train(train_set, valid_set)

print('Test accuracy: {}%'.format(neural_network.accuracy(test_set)))