import numpy as np
import matplotlib.pyplot as plt
import random
import gzip


class NeuronalNetwork:
    def __init__(self, n_input_size=28*28, n_output_size=10, hidden_layers=[100]):
        self.n_input_size, self.n_output_size = n_input_size, n_output_size
        self.weights, self.biases = [], []
        self.weights_gradients, self.biases_gradients = [], []

        #random sa dea la fel pentru tot(weight, bias etc.) - tot ce avem random
        np.random.seed(10)

        n_neurons_last_layer = self.n_input_size

        for n_neurons in hidden_layers + [self.n_output_size]:
            #weights avem 2 arrayuri unul pentru input- hidden iar celalat este de la hidden -> output
            #in weights avem valori din intervalul -10 si 10
            self.weights.append(
                #avem o distributie normala
                #0 - media distributiei
                #1./ - deviatia standard a distributiei
                #ultimul reprezinta marimea unui array este de 10x100
                np.random.normal(0, 1./np.sqrt(n_neurons_last_layer), [n_neurons_last_layer, n_neurons])

            )
            self.weights_gradients.append(
                np.zeros([n_neurons_last_layer, n_neurons])
            )

            self.biases.append(
                np.random.normal(0, 1, [n_neurons])
            )
            self.biases_gradients.append(
                np.zeros([n_neurons])
            )
            n_neurons_last_layer = n_neurons

        self.n_layers = len(self.weights)

    def learn(self, label, outputs, learning_rate, l2=0.00001, momentum=0.01):
        #facem update la weight
        #w = w + (t - output)x * n
        #weights_gradients si biases_gradients facem derivatele locale
        weights_gradients_list, biases_gradients_list = [], []

        #derivata de la layerul ultim(y)
        output_derivative = outputs[-1] - label

        for i in reversed(range(self.n_layers)):
            weights_gradient = np.dot(outputs[i].T, output_derivative)
            biases_gradient = output_derivative.sum(axis=0)

            # L2
            #daca weighturile si biasurile sunt mai mari atunci il penalizam mai mult
            weights_gradient += np.abs(self.weights[i]) * l2
            biases_gradient += np.abs(self.biases[i]) * l2

            weights_gradients_list.append(weights_gradient)
            biases_gradients_list.append(biases_gradient)

            output_derivative = np.dot(output_derivative, self.weights[i].T)
            output_derivative = output_derivative * self.activation_derivative(outputs[i])

        for i in range(self.n_layers):
            layer_weights_gradient = weights_gradients_list[self.n_layers - 1 - i] * learning_rate
            layer_biases_gradient = biases_gradients_list[self.n_layers - 1 - i] * learning_rate

            self.weights_gradients[i] = (
                self.weights_gradients[i] * momentum + layer_weights_gradient
            )
            self.biases_gradients[i] = (
                self.biases_gradients[i] * momentum + layer_biases_gradient
            )

            self.weights[i] -= self.weights_gradients[i]
            self.biases[i] -= self.biases_gradients[i]

    def softmax(self, x):
        #daca avem o singura categorie
        if len(x.shape) == 1:
            return np.exp(x) / np.sum(np.exp(x))
        else:
            return np.exp(x) / np.sum(np.exp(x), axis=1)

    #activation e sigmoid
    def activation(self, output):
        return 1 / (1 + np.exp(-output))

    def activation_derivative(self, output):
        activation = self.activation(output)
        return activation * (1 - activation)

    def feedforward(self, input, return_outputs=False):
        outputs = [input]

        layer = input
        for i, (weights, biases) in enumerate(zip(self.weights, self.biases)):
            layer = np.dot(layer, weights)
            layer = layer + biases

            if i < self.n_layers - 1:
                #activation = sigmoid
                layer = self.activation(layer)
            else:
                layer = self.softmax(layer)
            outputs.append(layer)

        if return_outputs:
            return outputs
        return layer

    def accuracy(self, test_set):
        # images vector cu imaginea 28x28=784
        # labels etichete - valoarea corespunzatoare pentru fiecare input
        #test_set = (images, labels)
        images, labels = test_set
        #calculam numnarul de linii al matricii
        n_images = images.shape[0]

        error = 0
        for idx in range(n_images):
            # idx e linia
            # 0: - toate coloanele
            image, label = images[idx, 0:], labels[idx]

            #salvam outputl retelei
            output = self.feedforward(image)

            #verificam output retea sa fie la fel cu eticheta
            if np.argmax(output) != label:
                error += 1
        return (n_images - error) / n_images

    def cross_entropy(self, output, expected_output):
        return -np.sum(expected_output * np.log(output))

    def train(self, training_set, validation_set, learning_rate=0.01):
        # image contine toate elementele de pe colana care corespund cu linia = idx din images
        # label are valoarea care ar trebui sa aiba image
        images, labels = training_set
        n_images = images.shape[0]

        all_classified = False
        #numar pasi - epcoci
        nr_iterations = 50
        n_iteration = 0
        while not all_classified and nr_iterations > 0:
            all_classified = True
            error = 0
            loss = 0.0
            for idx in range(n_images):
                #image contine toate elementele de pe colana care corespund cu linia = idx din images
                #label are valoarea care ar trebui sa aiba image
                image, label = images[[idx], :], labels[idx]


                value = [0] * self.n_output_size
                value[label] = 1
                value = np.array(value)
                #value are forma de vector a labeu-lui

                #feedforward
                outputs = self.feedforward(image, return_outputs=True)
                output = outputs[-1]
                #update weights
                self.learn(value, outputs, learning_rate)
                #ouptut - > loss
                loss += self.cross_entropy(output, value) / n_images

                #argmax da indexul cu valoarea maxima
                #valoarea maxima nu se afla in label
                network_label = np.argmax(output)
                if network_label != label:
                    all_classified = False
                    error += 1
            print(
                #afisare
                'Iteration #{} - Cost: {} Train err: {}% Validation err: {}%'.format(
                    n_iteration,
                    round(loss, 5),
                    round(error / n_images * 100, 3),
                    round((1. - self.accuracy(validation_set)) * 100, 3)
                )
            )

            nr_iterations = nr_iterations - 1
            n_iteration += 1
